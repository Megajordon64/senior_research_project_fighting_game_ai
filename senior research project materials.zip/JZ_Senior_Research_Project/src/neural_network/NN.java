package neural_network;

// code for neural network package referenced from:
// towarddatascience.com
public class NN {

}
